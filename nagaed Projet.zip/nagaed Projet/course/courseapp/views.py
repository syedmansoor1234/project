from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from .models import course
from .serializers import CourseSerializer


class CourseListCreate(generics.ListCreateAPIView):
    queryset = course.objects.all()
    serializer_class = CourseSerializer


class CourseRetrieveUpdateDestroy(generics.RetrieveUpdateDestroyAPIView):
    queryset = course.objects.all()
    serializer_class = CourseSerializer
